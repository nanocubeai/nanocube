# Changelog

## Version 0.5.0
- Drop support for 32-bit
- Drop support for Python 3.5, 3.6, 3.7
- Add support and pre-build manylinux binaries for Python 3.10, 3.11, 3.12
- Use oldest-supported-numpy build-time dependency
- Launch documentation at https://sortednp.dev/

## Version 0.4.1
- Fix build-time dependency setup ([PEP517](https://peps.python.org/pep-0517/) and [PEP518](https://peps.python.org/pep-0518/))

## Version 0.4.0
- Add set operations: `isitem()` and `issubset()`

## Version 0.3.0
 - Add multiple duplicate treatments
 - Add indices option for merge

## Version 0.2.1
 - Fix reference counting to prevent read-after-free for non-c-contiguous arrays

## Version 0.2.0
 - Add indices=True
 - Add support for Python 3.7

## Version 0.1.0
 - Add C++-backed intersect method
 - Add C++-backed merge method
 - Add k-way variants of intersect and merge
