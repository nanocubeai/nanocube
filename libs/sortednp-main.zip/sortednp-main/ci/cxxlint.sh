#!/bin/bash

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
python3 ${DIR}/cpplint.py --filter=-build/include ${DIR}/*.cpp \
    ${DIR}/../src/*.h  ${DIR}/../src/*.cpp 

if [ "$?" == "0" ]; then
    phrase="pass"
else
    phrase="fail"
fi
anybadge -o -l "C++ lint" -v "$phrase" -f cxxlint.svg pass=green fail=red
