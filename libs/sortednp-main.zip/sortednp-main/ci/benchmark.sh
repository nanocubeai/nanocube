#!/bin/bash

N_POINTS=${N_POINTS:-20}

python3 ci/benchmark.py --n-points $N_POINTS --merge \
    --intersect-simple --intersect-binary --intersect-galloping \
    --sparseness-simple --sparseness-binary --sparseness-galloping
