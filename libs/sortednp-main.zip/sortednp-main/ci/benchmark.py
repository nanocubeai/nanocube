#!/usr/bin/env python3

"""Create benchmark plots"""

from functools import reduce
import argparse
import timeit
import numpy as np
import matplotlib.pyplot as plt
import sortednp as snp

def np_kway_intersect(*arrays, assume_sorted, **_kwds):
    """Intersect all arrays iteratively"""
    if assume_sorted:
        # This information cannot be used
        pass

    return reduce(np.intersect1d, arrays)

def np_kway_merge(*arrays, assume_sorted, **_kwds):
    """Merge all arrays iteratively"""
    if assume_sorted:
        # This information cannot be used
        pass

    concatenation = np.concatenate(arrays)
    concatenation.sort()
    return concatenation

def get_time(func, *args, **kwds):
    """
    Time the given function call

    The method returns the execution time of the function when called with the
    given arguments and keywords and the return value of the function.
    """
    start_time = timeit.default_timer()
    result = func(*args, **kwds)
    return timeit.default_timer() - start_time, result

def benchmark(func, arrays, intermediate_results=None, assume_sorted=True,
              algorithm=None):
    """
    Run a generic benchmark test.

    The given func must be callable. This must be a k-way union or
    intersection for numpy of sortednp. The benchmark will use the given
    arrays as arguments. If the flag assume sorted is True, the algorithm will
    be called with the same argument and the benchmark sorts the arrays before
    the stop watch is started. If assume_sorted is False, the time it takes to
    sort the arrays is included in the execution time of the algorithm.

    If intermediate_results is set, the return value is a list of durations it
    took to process the number of arrays specified in intermediate_results.
    The number of calls of func is equal to the length of
    intermediate_results.
    """

    if intermediate_results is None:
        # Call self with intermediate_results and unwrap result
        return benchmark(func, arrays, [len(arrays)],
                         assume_sorted=assume_sorted,
                         algorithm=algorithm)[0]


    kwds = {"assume_sorted": assume_sorted}
    if algorithm is not None:
        kwds['algorithm'] = algorithm

    prev_result = arrays[0]
    processed_arrays = 1
    timings = []
    for last_array in sorted(intermediate_results):
        chunk = [prev_result] + arrays[processed_arrays:last_array]

        time, prev_result = get_time(func, *chunk, **kwds)

        timings.append(time)
        processed_arrays = last_array

    return np.cumsum(timings)

def get_random_array(size, sparseness=2):
    """
    Return an random array of the given size. The sparseness parameter
    describes how unlikely it is to have duplicated items. Higher values
    produce less duplicates.
    """
    dtype = 'int32'
    if size * sparseness > 1e9:
        dtype = 'int64'

    return (np.random.random(size=int(size)) * size * sparseness).astype(dtype)

def plot_intersect(assume_sorted=True, algorithm=None, max_size=1e7,
                   n_points=200):
    """
    Create the plot for the intersection benchmark.
    """
    plt.figure(figsize=(6, 4))
    plt.subplot(111)

    sizes = np.logspace(3, np.log10(max_size), n_points, dtype=int)
    intermediate_results = [2, 5, 10]

    ratios = []
    for size in sizes:
        arrays = [get_random_array(size)
                  for _ in range(max(intermediate_results))]

        if assume_sorted:
            for array in arrays:
                array.sort()

        snp_timing = benchmark(snp.kway_intersect, arrays,
                               intermediate_results,
                               assume_sorted, algorithm=algorithm)
        np_timing = benchmark(np_kway_intersect, arrays,
                              intermediate_results,
                              assume_sorted, algorithm=algorithm)

        ratios.append(snp_timing / np_timing)

    ratios = np.array(ratios)

    for n_array, points in zip(intermediate_results, ratios.T):
        plt.plot(sizes, points, "o", markersize=4,
                 label="%d arrays" % n_array)

    plt.xscale('log')
    plt.xlabel("Array size")
    plt.ylabel("Duration sortednp / numpy")
    plt.xlim([min(sizes), max(sizes)])
    plt.legend(frameon=False)
    plt.ylim([0.05, 0.40])
    plt.tight_layout()
    suffix = "_assume_sorted" if assume_sorted else ""
    if algorithm is not None:
        if algorithm == snp.SIMPLE_SEARCH:
            suffix += "_simple"
        elif algorithm == snp.BINARY_SEARCH:
            suffix += "_binary"
        elif algorithm == snp.GALLOPING_SEARCH:
            suffix += "_galloping"
        else:
            suffix += "_invalid"
    plt.savefig("bm_intersect%s.png" % suffix, dpi=300)
    plt.close()

def plot_sparseness(assume_sorted=True, algorithm=None,
                    max_sparseness=1000, n_points=200):
    """
    Create the plot for the intersection benchmark.
    """
    plt.figure(figsize=(6, 4))
    plt.subplot(111)

    sparsenesses = np.logspace(np.log10(2),
                               np.log10(max_sparseness),
                               n_points,
                               dtype=int)
    intermediate_results = [2, 5, 10]

    ratios = []
    for sparseness in sparsenesses:
        arrays = [get_random_array(1e6, sparseness)]
        arrays += [get_random_array(1e6)
                   for _ in range(max(intermediate_results) - 1)]

        if assume_sorted:
            for array in arrays:
                array.sort()

        snp_timing = benchmark(snp.kway_intersect, arrays,
                               intermediate_results,
                               assume_sorted, algorithm=algorithm)
        np_timing = benchmark(np_kway_intersect, arrays,
                              intermediate_results,
                              assume_sorted, algorithm=algorithm)

        ratios.append(snp_timing / np_timing)

    ratios = np.array(ratios)

    for n_array, points in zip(intermediate_results, ratios.T):
        plt.plot(sparsenesses, points, "o", markersize=4,
                 label="%d arrays" % n_array)

    plt.xscale('log')
    plt.xlabel("Sparseness")
    plt.ylabel("Duration sortednp / numpy")
    plt.xlim([min(sparsenesses), max(sparsenesses)])
    plt.ylim([0, 0.2])
    plt.legend(frameon=False)
    plt.tight_layout()
    suffix = "_assume_sorted" if assume_sorted else ""
    if algorithm is not None:
        if algorithm == snp.SIMPLE_SEARCH:
            suffix += "_simple"
        elif algorithm == snp.BINARY_SEARCH:
            suffix += "_binary"
        elif algorithm == snp.GALLOPING_SEARCH:
            suffix += "_galloping"
        else:
            suffix += "_invalid"
    plt.savefig("bm_sparseness%s.png" % suffix, dpi=300)
    plt.close()

def plot_merge(assume_sorted=True, max_size=1e6, n_points=200):
    """
    Create the plot for the merge benchmark.
    """
    plt.figure(figsize=(6, 4))
    plt.subplot(111)

    sizes = np.logspace(3, np.log10(max_size), n_points, dtype=int)
    intermediate_results = [2, 5, 10]

    ratios = []
    for size in sizes:
        arrays = [get_random_array(size)
                  for _ in range(max(intermediate_results))]

        if assume_sorted:
            for array in arrays:
                array.sort()

        snp_timing = benchmark(snp.kway_merge, arrays,
                               intermediate_results,
                               assume_sorted)
        np_timing = benchmark(np_kway_merge, arrays,
                              intermediate_results,
                              assume_sorted)

        ratios.append(snp_timing / np_timing)

    ratios = np.array(ratios)

    for n_array, points in zip(intermediate_results, ratios.T):
        plt.plot(sizes, points, "o", markersize=4,
                 label="%d arrays" % n_array)

    plt.xscale('log')
    plt.xlabel("Array size")
    plt.ylabel("Duration sortednp / numpy")
    plt.xlim([min(sizes), max(sizes)])
    plt.legend(frameon=False)
    plt.tight_layout()
    suffix = "_assume_sorted" if assume_sorted else ""
    plt.savefig("bm_merge%s.png" % suffix, dpi=300)
    plt.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Create benchmark plots to compare the sortednp package"
                    " to the default numpy methods.")

    parser.add_argument("--n-points", "-n", default=200, type=int,
                        help="Compute n points for each plot")

    parser.add_argument("--merge", action="store_true",
                        help="Benchmark merge operation.")

    parser.add_argument("--intersect-simple", action="store_true",
                        help="Benchmark intersect operation using simple"
                        " search algorithm.")

    parser.add_argument("--intersect-binary", action="store_true",
                        help="Benchmark intersect operation using binary"
                        " search algorithm.")

    parser.add_argument("--intersect-galloping", action="store_true",
                        help="Benchmark intersect operation using galloping"
                        " search algorithm.")

    parser.add_argument("--sparseness-simple", action="store_true",
                        help="Benchmark intersect with sparseness operation "
                        "using simple search algorithm.")

    parser.add_argument("--sparseness-binary", action="store_true",
                        help="Benchmark intersect with sparseness operation "
                        "using simple search algorithm.")

    parser.add_argument("--sparseness-galloping", action="store_true",
                        help="Benchmark intersect with sparseness operation "
                        "using simple search algorithm.")

    cli_args = parser.parse_args()

    if cli_args.merge:
        print("Benchmarking merge")
        plot_merge(True, n_points=cli_args.n_points)

    if cli_args.intersect_simple:
        print("Benchmarking intersect simple")
        plot_intersect(True, n_points=cli_args.n_points,
                       algorithm=snp.SIMPLE_SEARCH)

    if cli_args.intersect_binary:
        print("Benchmarking intersect binary")
        plot_intersect(True, n_points=cli_args.n_points,
                       algorithm=snp.BINARY_SEARCH)

    if cli_args.intersect_galloping:
        print("Benchmarking intersect galloping")
        plot_intersect(True, n_points=cli_args.n_points,
                       algorithm=snp.GALLOPING_SEARCH)

    if cli_args.sparseness_simple:
        print("Benchmarking sparseness simple")
        plot_sparseness(True, n_points=cli_args.n_points,
                        algorithm=snp.SIMPLE_SEARCH)

    if cli_args.sparseness_binary:
        print("Benchmarking sparseness binary")
        plot_sparseness(True, n_points=cli_args.n_points,
                        algorithm=snp.BINARY_SEARCH)

    if cli_args.sparseness_galloping:
        print("Benchmarking sparseness galloping")
        plot_sparseness(True, n_points=cli_args.n_points,
                        algorithm=snp.GALLOPING_SEARCH)
