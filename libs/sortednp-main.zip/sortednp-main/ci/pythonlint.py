#!/usr/bin/env python3

import sys
import os
from pylint.lint import Run
import anybadge

args = [
    "--disable=c0103,e0611,e1101,r0903,w0707,c0209",
    os.path.join(os.path.dirname(__file__), "../setup.py"),
    os.path.join(os.path.dirname(__file__), "benchmark.py"),
    "sortednp.__init__",
    "--extension-pkg-allow-list", "sortednp._internal"
]


results = Run(args, exit=False)
status = results.linter.msg_status
score = "%.2f" % results.linter.stats.global_note

thresholds = {8: 'red',
              9: 'orange',
              9.9: 'yellow',
              10: 'green'}
badge = anybadge.Badge('Python lint', score, thresholds=thresholds)
badge.write_badge('pylint.svg', overwrite=True)

sys.exit(status)
