#!/bin/bash

PYTHON_VERSIONS="3.12 3.11 3.10 3.9 3.8"

for PYTHON_VERSION in ${PYTHON_VERSIONS}; do
    docker build -t gitlab.sauerburger.com:5049/frank/sortednp/py_gtest:${PYTHON_VERSION} -f ci/gtest.Dockerfile --build-arg PYTHON_VERSION=${PYTHON_VERSION} .
done

for PYTHON_VERSION in ${PYTHON_VERSIONS}; do
    docker push gitlab.sauerburger.com:5049/frank/sortednp/py_gtest:${PYTHON_VERSION}
done