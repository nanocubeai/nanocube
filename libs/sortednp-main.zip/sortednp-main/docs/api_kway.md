
::: sortednp.kway